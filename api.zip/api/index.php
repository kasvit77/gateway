<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';

$app = new \Slim\App;


$app->get('/items[/{id:[0-9]+}]', function (Request $request, Response $response) {
	
    // В качестве $args['id'] будут приниматься только числа
	 $name = $request->getAttribute('id');

	  return $response->withJson(['response' => 'success', 'users' => $name]);
	  
});
$app->run();